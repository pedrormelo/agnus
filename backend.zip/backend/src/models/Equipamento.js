const db = require('../config/db');

const Equipamento = {
    getAll: async () => {
        const [rows] = await db.query(`SELECT * FROM equipamentos`);
        return rows;
    },

    getById: async (id) => {
        const [rows] = await db.query(`SELECT * FROM equipamentos WHERE idEquip = ?`, [id]);
        return rows[0];
    },

    create: async (dados) => {
        const { idTomb, ambiente, descDefeito, tipo, idUnidade, idTecnico } = dados;

        const [result] = await db.query(
            `INSERT INTO equipamentos (idTomb, ambiente, descDefeito, tipo, idUnidade, idTecnico) VALUES (?, ?, ?, ?, ?, ?)`,
            [idTomb, ambiente, descDefeito, tipo, idUnidade, idTecnico]
        );

        const idEquip = result.insertId;

        // Gera o código no formato yyyymmNNNN
        const now = new Date();
        const anoMes = now.getFullYear().toString() + String(now.getMonth() + 1).padStart(2, '0');
        const codigoEtiqueta = `${anoMes}${String(idEquip).padStart(4, '0')}`;

        // Atualiza o equipamento com o código gerado
        await db.query(`UPDATE equipamentos SET codigoEtiqueta = ? WHERE idEquip = ?`, [codigoEtiqueta, idEquip]);

        return { idEquip, codigoEtiqueta };
    },


    // create: async (dados) => {
    //     const {
    //         idTomb,
    //         ambiente,
    //         descDefeito,
    //         tipo,
    //         status = 'ENTRADA',
    //         dataEntrada = new Date(),
    //         dataSaida = null,
    //         idUnidade,
    //         idTecnico
    //     } = dados;

    //     // 1. Inserir equipamento (sem o códigoEtiqueta ainda)
    //     const [result] = await db.query(
    //         `INSERT INTO equipamentos 
    //             (idTomb, ambiente, descDefeito, tipo, status, dataEntrada, dataSaida, idUnidade, idTecnico)
    //         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    //         [idTomb, ambiente, descDefeito, tipo, status, dataEntrada, dataSaida, idUnidade, idTecnico]
    //     );

    //     const idEquip = result.insertId;

    //     // 2. Gerar códigoEtiqueta no formato yyyymmNNNN
    //     const now = new Date();
    //     const ano = now.getFullYear();
    //     const mes = String(now.getMonth() + 1).padStart(2, '0');
    //     const sequencia = String(idEquip).padStart(4, '0');
    //     const codigoEtiqueta = `${ano}${mes}${sequencia}`;

    //     // 3. Atualizar o registro com o código gerado
    //     await db.query(
    //         `UPDATE equipamentos SET codigoEtiqueta = ? WHERE idEquip = ?`,
    //         [codigoEtiqueta, idEquip]
    //     );

    //     return idEquip;
    // }
};

module.exports = Equipamento;
